public class Pistolero{
    String nombre;
    Integer recompensa=0;
    ArrayList capturas;

    public Pistolero(String nombre, int recompensa){
        this.nombre=nombre;
        this.recompensa=recompensa;
    }


    

}